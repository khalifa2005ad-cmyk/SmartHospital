SmartHospital Pro - Khalifa Ahmed

This ZIP contains code sections for study and for showing the doctor.
The sections come from the original SmartHospital project and follow the presentation's division of responsibilities.
Each file shows the original filename and line numbers.
These are CODE EXCERPTS, not a standalone runnable app.
The original app.py is shared between team members.
These files do not prove who personally wrote each line; confirm actual contributions with the team.

Sections:
- Doctors_List.txt: app.py lines 37-44
- Doctors_Page.txt: app.py lines 765-795
- Appointments_Page.txt: app.py lines 796-1255
- Navigation.txt: app.py lines 1256-1333
