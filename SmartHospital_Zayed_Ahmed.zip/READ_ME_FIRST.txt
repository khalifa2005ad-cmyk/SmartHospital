SmartHospital Pro - Zayed Ahmed

This ZIP contains code sections for study and for showing the doctor.
The sections come from the original SmartHospital project and follow the presentation's division of responsibilities.
Each file shows the original filename and line numbers.
These are CODE EXCERPTS, not a standalone runnable app.
The original app.py is shared between team members.
These files do not prove who personally wrote each line; confirm actual contributions with the team.

Sections:
- Imports.txt: app.py lines 1-8
- Main_Window.txt: app.py lines 48-55
- JSON_Data.txt: app.py lines 56-96
- Dashboard.txt: app.py lines 230-356
